# -*- coding: utf-8 -*-

#from IPython import get_ipython
#def __reset__(): get_ipython().magic('reset -sf')


import pip

packages=['bert','numpy','pandas','PyPDF2','fpdf','textract','python-docx','os','json','tensorflow','nltk==3.4.5','tokenization','pandas','re','collections','unicodedata','six','copy','math','django','seqeval==0.0.5','fastprogress==0.1.21','tensorflow-gpu==2.0','argparse','csv','logging','random','shutil','sys','datetime']

def import_or_install(package):
    for i in packages:
        try:
            __import__(i)
            print('worked')
        except ImportError:
            pip.main(['install', i])  
            print('installed')
            
            
            
            

from bert import Ner
import pandas as pd
import PyPDF2
from fpdf import FPDF
import textract
from docx import Document
import docx
import os
import json
import tensorflow as tf
from nltk import word_tokenize
from tokenization import FullTokenizer
import pandas as pd
import re
import collections
import re
import unicodedata
import six 
import copy
import json
import math
import six
import tensorflow as tf
import django
import argparse
import csv
import json
import logging
import math
import os
import random
import shutil
import sys
import numpy as np
import tensorflow as tf
from fastprogress import master_bar, progress_bar
from seqeval.metrics import classification_report
from optimization import AdamWeightDecay, WarmUp
from tokenization import FullTokenizer
from datetime import datetime
