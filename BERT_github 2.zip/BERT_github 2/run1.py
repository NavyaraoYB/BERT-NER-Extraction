#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 22 13:06:19 2020

@author: navyarao
"""

from bert import Ner
import pandas as pd
import PyPDF2
from fpdf import FPDF
import textract
from docx import Document
import docx
import os  
from textblob.sentiments import PatternAnalyzer
from textblob import TextBlob, Word, Blobber
from pandas import *
import json
keywordSet = ["don't","never",  "nowhere",  "none", "not","can't","couldn't","shouldn't","should not","won't",
                  "wouldn't","don't","doesn't","didn't"]

#model = Ner("/Users/navyarao/Downloads/Vaco_main/Vaco/BERT_github/out_base/")


def input_path(folder,out_folder,model_path):
    print('executed')
    model = Ner(model_path)
    print('check')
    count = [name for name in os.listdir(folder) if name != ".DS_Store"]
    for file in count:
        print(file)
        fil_name=os.path.basename(file)
        fil_name=os.path.splitext(fil_name)[0]
        new_path=out_folder+fil_name
        ext = os.path.splitext(file)[-1].lower()
        path_entire=folder+file
        if ext == ".txt":
            output_lis=[]
            freq_lis=[]
            Empt_df=pd.DataFrame()               
            with open(path_entire, 'rb') as reader:
                a=reader.read()
                b=a.decode("utf-8") 
                fin_txt = b.split("\n\n")
                Empt_df=pd.DataFrame()
                for i in range(0,len(fin_txt)):
                    state=fin_txt[i].find('data preference')==-1
                    if state==False:
                        strn=fin_txt[i].split("data preference:",1)[1]
                        fin_str=strn.split('.')[0]
                        state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                    if state==False:
                        name=fin_txt[i].split("Name:",1)[1]
                        fin_name=name.split(',')[0]
                        email=fin_txt[i].split("email:",1)[1]
                        fin_email=email.split(',')[0]
                        phone=fin_txt[i].split("phone:",1)[1]
                        fin_phone=phone.split(',')[0]
                        fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                        Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                    lines=fin_txt[i].split(".")
                    if len(lines)>=1:
                        for j in range(0,len(lines)):
                            output,sent,freq = model.predict(lines[j])
                            output_lis.append(output)
                            lines[j]=sent
                            print(lines[j])
                            freq_lis.append(freq)
                        lines1='.'.join(lines)
                        fin_txt[i]=lines1
            with open(new_path, 'wb') as outp:
                outp.write(("\n\n".join(fin_txt)).encode())
                
        elif ext == ".pdf":
            text = textract.process(path_entire)
            text1=text.decode("utf-8") 
            output,sent,freq = model.predict(text1)
            with open(new_path, 'wb') as outp:
                outp.write(sent.encode())
            #pdf.set_font('arial', 'B', 13.0)
            #pdf.cell(ln=0, h=5.0, align='L', w=0, txt=sent, border=0)
            #pdf.output(file, 'F')
        elif ext==".docx":
            output_lis=[]
            freq_lis=[]
            fin_txt=[]
            Empt_df=pd.DataFrame()               
            document = Document(path_entire)
            for line in document.paragraphs:
                fin_txt.append(line.text)
            for i in range(0,len(fin_txt)):
                state=fin_txt[i].find('data preference')==-1
                if state==False:
                    strn=fin_txt[i].split("data preference:",1)[1]
                    fin_str=strn.split('.')[0]
                    state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                if state==False:
                    name=fin_txt[i].split("Name:",1)[1]
                    fin_name=name.split(',')[0]
                    email=fin_txt[i].split("email:",1)[1]
                    fin_email=email.split(',')[0]
                    phone=fin_txt[i].split("phone:",1)[1]
                    fin_phone=phone.split(',')[0]
                    fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                    Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                lines=fin_txt[i].split(".")
                if len(lines)>=1:
                    for j in range(0,len(lines)):
                        output,sent,freq = model.predict(lines[j])
                        output_lis.append(output)
                        lines[j]=sent
                        freq_lis.append(freq)
                    lines1='.'.join(lines)
                    fin_txt[i]=lines1
            new_txt='\n'.join(fin_txt)
            doc = docx.Document()
            doc.add_paragraph(new_txt)
            doc.save(new_path)
        elif ext==".xls" or ext==".xlsx":
            freq_lis=[] 
            Empt_df=pd.DataFrame()               
            df = pd.read_excel(path_entire)
            df = pd.DataFrame(df, columns= ['index','text'])
            for i in range(0,len(df)):
                print(i)
                txt=str(df['text'][i])
                state=txt.find('data preference')==-1
            if state==False:
                strn=txt.split("data preference:",1)[1]
                fin_str=strn.split('.')[0]
                state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
            if state==False:
                name=txt.split("Name:",1)[1]
                fin_name=name.split(',')[0]
                email=txt.split("email:",1)[1]
                fin_email=email.split(',')[0]
                phone=txt.split("phone:",1)[1]
                fin_phone=phone.split(',')[0]
                fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                Empt_df=pd.concat([fin_df,Empt_df],axis=0)
            lines=txt.split('.')
        if len(lines)>=1:
            for j in range(0,len(lines)):
                print(j)
                output,sent,freq = model.predict(lines[j])
                lines[j]=sent
                freq_lis.append(freq)
            lines1='.'.join(lines)
            df['text'][i]=lines1
            new_path=new_path+".xlsx"
            df.to_excel(new_path,index=False)
        elif ext==".csv":
            freq_lis=[] 
            Empt_df=pd.DataFrame()               
            df=pd.read_csv(path_entire)               
            df.columns=['index','text']
            for i in range(0,len(df)):
                print(i)
                txt=str(df['text'][i])
                state=txt.find('data preference')==-1
            if state==False:
                strn=txt.split("data preference:",1)[1]
                fin_str=strn.split('.')[0]
                state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
            if state==False:
                name=txt.split("Name:",1)[1]
                fin_name=name.split(',')[0]
                email=txt.split("email:",1)[1]
                fin_email=email.split(',')[0]
                phone=txt.split("phone:",1)[1]
                fin_phone=phone.split(',')[0]
                fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                Empt_df=pd.concat([fin_df,Empt_df],axis=0)
            lines=txt.split('.')
        if len(lines)>=1:
            for j in range(0,len(lines)):
                print(j)
                output,sent,freq = model.predict(lines[j])
                lines[j]=sent
                freq_lis.append(freq)
            lines1='.'.join(lines)
            df['text'][i]=lines1
            new_path=new_path+".csv"
            df.to_csv(new_path)
        lis=[freq_lis,new_path,Empt_df]
        my_string = json.dumps(lis)
    return(my_string)