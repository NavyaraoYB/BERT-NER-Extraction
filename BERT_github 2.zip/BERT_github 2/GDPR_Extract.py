import re
import json
import copy
import pandas as pd
'''
Empty dictionary and list which will form the basis for feeding the json file and 
csv file respectively
'''
my_dict = {}
my_list = []

DATA_PREF={
    'Do not share my data': 'DNS_1',
    'Share my data for only 30 days': 'DNS_2',
    'Share my data only with wholly owned subsidiaries': 'DNS_3',
    'Share my data with 3rd parties': 'DNS_4'
}

'''
This method calls out other methods which are the workers.
'''
def get_data():

    with open ('gdpr_extract.csv', 'w') as f:
        f.write('Name,email,phone,data preference,Flag' + '\n')
    
    '''
    Giving an option for user to choose which file to pick.
    Update "demo_file" OR "real_file" as the param to the method get_file_extract
    '''
    real_file = "/Users/navyarao/Downloads/Vaco_main/new_files/test.txt"
    

    lines = get_file_extract(real_file)

    my_list = get_data_from_extracted_lines(lines)
    #print('Total extracted lines are {}'.format(len(my_list)))

    
'''
Does the following jobs:
1. Extracts the line which has "Name:.*" in them and returns a list of lines.
2. Calculates the number of lines that have Vs total number of lines in the input file.
'''
def get_file_extract(input_file):
    with open(input_file, "rt") as f:
        my_file = f.read()
        extracted_lines = re.findall(r'\s*Name\s*:.*', my_file)
    
        with open(input_file, 'r') as f1:
            my_file_lines = f1.readlines()
            my_file_lines = [line for line in my_file_lines if not line.isspace()]
      
        if len(my_file_lines) != len(extracted_lines):
            print('length of original file: {}'.format(len(my_file_lines)))
            print('length of extracted line: {}'.format(len(extracted_lines)))

    return extracted_lines

'''
Does the following job
1. Uses regular expression to extract the specific data.
2. Highlights if a specific line does not follow the pattern expected.
3. Appends the data to the my_dict dictionary
4. Appends the data to the csv file.
5. Returns the list containing the matched lines.
'''
def get_data_from_extracted_lines(lines):
    for line in lines:
        m = re.search(r'\s*Name\s*:\s*(.*)\s*,\s*email\s*:\s*(.*)\s*,\s*Phone\s*:\s*(.*)\s*,\s*data\s*preference\s*:\s*([^.]*)', line, re.IGNORECASE)
        if m is None:
            print('This line did not have required data {}'.format(line))
            continue
        name = m.group(1)
        email = m.group(2)
        phone = m.group(3)
        data_pref = m.group(4)
        if 'Name' in name:
            name = find_actual_name(name)
        my_dict['Name'] =  name
        my_dict['Email'] = email
        my_dict['phone'] = phone
        my_dict['data preference'] = data_pref

        out = name + ',' + email + ',' + phone + ',' + data_pref
        for k,v in DATA_PREF.items():
            if k in m.group(4):
                out = out + ',' + v + '\n'
                my_dict['flag'] = v
                my_list.append(copy.deepcopy(my_dict))

        with open('output_file.csv', 'a') as fout:
            fout.write(out)
    
    return my_list





'''
Does the following job:
1. Extracts the actual value of "Name:" in case there are multiple entries
'''
def find_actual_name(name):
    name_list = name.split("Name:")
    return name_list[1]

file='/Users/navyarao/Downloads/Vaco_main/Vaco/output_file.csv'
out_folder='/Users/navyarao/Downloads/Vaco_main/Frequency/'

def Frequency_DataPreference(file,out_folder):
    df_dp=pd.read_csv(file)
    Freq_table=pd.DataFrame(df_dp['Share my data for only 30 days'].value_counts())
    Freq_table.to_csv(out_folder+'Frequency_DataPreference.csv')
    return(Freq_table)
Frequency_DataPreference(file,out_folder)

if __name__ == "__main__":
    get_data()

