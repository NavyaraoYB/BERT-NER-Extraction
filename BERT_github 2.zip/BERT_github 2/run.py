#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  5 23:52:47 2020

@author: navyarao
"""

from bert import Ner
import pandas as pd
import PyPDF2
from fpdf import FPDF
import textract
from docx import Document
import docx
import os  
from textblob.sentiments import PatternAnalyzer
from textblob import TextBlob, Word, Blobber
from pandas import *
from datetime import datetime

model = Ner("/Users/navyarao/Downloads/Vaco_main/Vaco/BERT_github/out_base/")
#output = model.predict("4556502216841044 credit card number which i reported")
new_path="/Users/navyarao/Downloads/Vaco_main/input_fold/created_test.txt"
           
            
model_path="/Users/navyarao/Downloads/Vaco_main/Vaco/BERT_github/out_base/"  
folder="/Users/navyarao/Downloads/Vaco_main/input_fold/" 
out_folder="/Users/navyarao/Downloads/Vaco_main/new_files/"
GDPR_file='/Users/navyarao/Downloads/Vaco_main/Vaco/output_file.csv'            
     
    
def input_path(folder,out_folder,model_path,GDPR_file):
    print('executed')
    model = Ner(model_path)
    print('check')
    #keywordSet = ["don't","never",  "nowhere",  "none", "not","can't","couldn't","shouldn't","should not","won't",
                  #"wouldn't","don't","doesn't","didn't"]
    #Empt_df=pd.DataFrame()
    count = [name for name in os.listdir(folder) if name != ".DS_Store"]
    freq_lis_txt=[]
    freq_lis_csv=[]
    fin_lis_doc=[]
    fin_lis_xl=[]
    freq_pdf=[]
    for file in count:
        print(file)
        fil_name=os.path.basename(file)
        fil_name=os.path.splitext(fil_name)[0]
        new_path=out_folder+fil_name
        ext = os.path.splitext(file)[-1].lower()
        path_entire=folder+file
        if ext == ".txt":
            with open(path_entire, 'rb') as reader:
                a=reader.read()
                b=a.decode("utf-8") 
                fin_txt = b.split("\n\n")
                #Empt_df=pd.DataFrame()
                for i in range(0,len(fin_txt)):
                    #state=fin_txt[i].find('data preference')==-1
                    #if state==False:
                        #strn=fin_txt[i].split("data preference:",1)[1]
                        #fin_str=strn.split('.')[0]
                        #state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                    #if state==False:
                        #name=fin_txt[i].split("Name:",1)[1]
                        #fin_name=name.split(',')[0]
                        #email=fin_txt[i].split("email:",1)[1]
                        #fin_email=email.split(',')[0]
                        #phone=fin_txt[i].split("phone:",1)[1]
                        #fin_phone=phone.split(',')[0]
                        #fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                        #Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                    lines=fin_txt[i].split(".")
                    if len(lines)>1:
                        for j in range(0,len(lines)):
                            output,sent,freq = model.predict(lines[j])
                            lines[j]=sent
                            #print(lines[j])
                            freq_lis_txt.append(freq)
                        #freqency=pd.DataFrame(freq_lis)
                        #Non_masked=freqency['O'].sum()
                        #Masked=freqency['MSK'].sum()
                        #Frequncy=pd.DataFrame({'Masked':[Masked],'Non_masked':[Non_masked]})
                        #Frequency_table_txt=pd.concat([Frequency_table_txt,Frequncy],axis=0)
                        lines1='.'.join(lines)
                        fin_txt[i]=lines1
            with open(new_path, 'wb') as outp:
                outp.write(("\n\n".join(fin_txt)).encode())        
        elif ext == ".pdf":
            text = textract.process(path_entire)
            text1=text.decode("utf-8") 
            output,sent,freq = model.predict(text1)
            freq_pdf.append(freq)
            with open(new_path, 'wb') as outp:
                outp.write(sent.encode())
            #pdf.set_font('arial', 'B', 13.0)
            #pdf.cell(ln=0, h=5.0, align='L', w=0, txt=sent, border=0)
            #pdf.output(file, 'F')
        elif ext==".docx":
            #Frequency_table=pd.DataFrame()
            document = Document(path_entire)
            for line in document.paragraphs:
                fin_txt.append(line.text)
            for i in range(0,len(fin_txt)):
                #state=fin_txt[i].find('data preference')==-1
                #if state==False:
                    #strn=fin_txt[i].split("data preference:",1)[1]
                    #fin_str=strn.split('.')[0]
                    #state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                #if state==False:
                """
                    name=fin_txt[i].split("Name:",1)[1]
                    fin_name=name.split(',')[0]
                    email=fin_txt[i].split("email:",1)[1]
                    fin_email=email.split(',')[0]
                    phone=fin_txt[i].split("phone:",1)[1]
                    fin_phone=phone.split(',')[0]
                    fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                    Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                """
                lines=fin_txt[i].split(".")
                if len(lines)>1:
                    for j in range(0,len(lines)):
                        output,sent,freq = model.predict(lines[j])
                        lines[j]=sent
                        fin_lis_doc.append(freq)
                    #freqency=pd.DataFrame(fin_lis_doc)
                    #Non_masked=freqency['O'].sum()
                    #Masked=freqency['MSK'].sum()
                    #Frequncy=pd.DataFrame({'Masked':[Masked],'Non_masked':[Non_masked]})
                    #Frequency_table=pd.concat([Frequency_table,Frequncy],axis=0)
                    #Frequency_table.to_csv(out_folder+fil_name+".csv")
                    lines1='.'.join(lines)
                    fin_txt[i]=lines1
            new_txt='\n'.join(fin_txt)
            doc = docx.Document()
            doc.add_paragraph(new_txt)
            doc.save(new_path)
        elif ext==".xls" or ext==".xlsx":
            #Frequency_table=pd.DataFrame()
            #freq_lis=[] 
            df = pd.read_excel(path_entire)
            df = pd.DataFrame(df, columns= ['index','text'])
            for i in range(0,len(df)):
                #print(i)
                txt=str(df['text'][i])
                #state=txt.find('data preference')==-1
                #if state==False:
                    #strn=txt.split("data preference:",1)[1]
                    #fin_str=strn.split('.')[0]
                    #state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                #if state==False:
                """
                    name=txt.split("Name:",1)[1]
                    fin_name=name.split(',')[0]
                    email=txt.split("email:",1)[1]
                    fin_email=email.split(',')[0]
                    phone=txt.split("phone:",1)[1]
                    fin_phone=phone.split(',')[0]
                    fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                    Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                """
                lines=txt.split('.')
                if len(lines)>1:
                    for j in range(0,len(lines)):
                        #print(j)
                        output,sent,freq = model.predict(lines[j])
                        lines[j]=sent
                        fin_lis_xl.append(freq)
                    #freqency=pd.DataFrame(freq_lis)
                    #Non_masked=freqency['O'].sum()
                    #Masked=freqency['MSK'].sum()
                    #Frequncy=pd.DataFrame({'Masked':[Masked],'Non_masked':[Non_masked]})
                    #Frequency_table=pd.concat([Frequency_table,Frequncy],axis=0)
                    #Frequency_table.to_csv(out_folder+fil_name+".csv")
                    lines1='.'.join(lines)
                    df['text'][i]=lines1
            new_path=new_path+".xlsx"
            df.to_excel(new_path,index=False)
        elif ext==".csv":
            df=pd.read_csv(path_entire)               
            df.columns=['index','text']
            for i in range(0,len(df)):
                #print(i)
                txt=str(df['text'][i])
                #state=txt.find('data preference')==-1
                #if state==False:
                    #strn=txt.split("data preference:",1)[1]
                    #fin_str=strn.split('.')[0]
                    #state=len([each for each in keywordSet if each.lower() in fin_str.lower()])>=1
                #if state==False:
                """
                    name=txt.split("Name:",1)[1]
                    fin_name=name.split(',')[0]
                    email=txt.split("email:",1)[1]
                    fin_email=email.split(',')[0]
                    phone=txt.split("phone:",1)[1]
                    fin_phone=phone.split(',')[0]
                    fin_df = pd.DataFrame({'Name': [fin_name], 'email': [fin_email],'phone':[fin_phone]})
                    Empt_df=pd.concat([fin_df,Empt_df],axis=0)
                """
                lines=txt.split('.')
                if len(lines)>1:
                    for j in range(0,len(lines)):
                        #print(j)
                        output,sent,freq = model.predict(lines[j])
                        lines[j]=sent
                        freq_lis_csv.append(freq)
                    lines1='.'.join(lines)
                    df['text'][i]=lines1
            new_path=new_path+".csv"
            df.to_csv(new_path)
     
    if len(freq_lis_txt)>=1:
        freqency=pd.DataFrame(freq_lis_txt)
        Non_masked=freqency['O'].sum()
        Masked=freqency['MSK'].sum()
        fin_Frequncy_txt=pd.DataFrame({'Masked':[Masked],'Non_masked':[Non_masked]})
        #fin_Frequncy_txt.to_csv(out_folder+"txt_file_frequency.csv")
    else:
        fin_Frequncy_txt=pd.DataFrame()
        
    if len(freq_lis_csv)>=1:
        freqency_csv=pd.DataFrame(freq_lis_csv)
        Non_masked_csv=freqency_csv['O'].sum()
        Masked_csv=freqency_csv['MSK'].sum()
        fin_Frequncy_csv=pd.DataFrame({'Masked':[Masked_csv],'Non_masked':[Non_masked_csv]})
        #fin_Frequncy_csv.to_csv(out_folder+"csv_file_frequency.csv")
    else:
        fin_Frequncy_csv=pd.DataFrame()
        
    if len(fin_lis_doc)>=1:
        freqency_doc=pd.DataFrame(fin_lis_doc)
        Non_masked_doc=freqency_doc['O'].sum()
        Masked_doc=freqency_doc['MSK'].sum()
        fin_Frequncy_doc=pd.DataFrame({'Masked':[Masked_doc],'Non_masked':[Non_masked_doc]})
        #fin_Frequncy_doc.to_csv(out_folder+"doc_file_frequency.csv")
    else:
        fin_Frequncy_doc=pd.DataFrame()
        
    if len(fin_lis_xl)>=1:
        freqency_xl=pd.DataFrame(fin_lis_xl)
        Non_masked_xl=freqency_xl['O'].sum()
        Masked_xl=freqency_xl['MSK'].sum()
        fin_Frequncy_xl=pd.DataFrame({'Masked':[Masked_xl],'Non_masked':[Non_masked_xl]})
        #fin_Frequncy_xl.to_csv(out_folder+"xl_file_frequency.csv")
    else:
        fin_Frequncy_xl=pd.DataFrame()
        
    if len(freq_pdf)>=1:
        freqency_pdf=pd.DataFrame(freq_pdf)
        fin_Frequncy_pdf=pd.DataFrame({'Masked':[freqency_pdf['O'].sum()],'Non_masked':[freqency_pdf['Non_masked'].sum()]})
        #fin_Frequncy_pdf.to_csv(out_folder+"pdf_file_frequency.csv")
    else:
        fin_Frequncy_pdf=pd.DataFrame()
        
    Overall_freq=pd.concat([fin_Frequncy_txt,fin_Frequncy_csv,fin_Frequncy_doc,fin_Frequncy_xl,fin_Frequncy_pdf],axis=0)
    Non_masked_overall=Overall_freq['Non_masked'].sum()
    Masked_overall=Overall_freq['Masked'].sum()
    fin_Frequncy_overall=pd.DataFrame({'Masked':[Masked_overall],'Non_masked':[Non_masked_overall]})
    fin_Frequncy_overall.to_csv(out_folder+"overall_file_frequency.csv")
    
    #now = datetime.now()
    #dt_string = now.strftime("%d%m%Y%H:%M:%S")
    #file_name="cust_details"+"_"+dt_string+".csv"
    #Empt_df.to_csv(out_folder+file_name)
    #print(Frequency_table)
    #Frequency_table.reset_index(inplace=True)
    #Frequency_table1 = Frequency_table.to_json()
    return(fin_Frequncy_overall)        


input_path(folder,out_folder,model_path)


#path_entire='/Users/navyarao/Downloads/Vaco_main/input_fold/test.csv'


#Masking/replace
#File Formats generic execution
#Packaging
#train_statistics
#Frequency table




